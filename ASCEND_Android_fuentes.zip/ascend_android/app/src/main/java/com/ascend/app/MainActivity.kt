package com.ascend.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val colors = intArrayOf(Color.rgb(34,197,94), Color.rgb(59,130,246), Color.rgb(239,68,68), Color.rgb(168,85,247))
    private val stages = arrayOf("VERDE", "AZUL", "ROJO", "MORADO")
    private val prefs by lazy { getSharedPreferences("ascend", Context.MODE_PRIVATE) }
    private var stage = 0
    private var days = 0
    private var steps = 0
    private lateinit var progress: TextView
    private lateinit var bar: ProgressBar
    private lateinit var stepText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stage = prefs.getInt("stage", 0); days = prefs.getInt("days", 0); steps = prefs.getInt("steps", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 36, 24, 24); setBackgroundColor(Color.BLACK) }
        fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 10, 0, 10) }
        root.addView(text("ASCEND", 30f, Color.WHITE, true))
        val stageText = text("ETAPA ${stages[stage]}", 15f, colors[stage], true); root.addView(stageText)
        progress = text("$days% · $days de 100 días", 20f, Color.WHITE, true); root.addView(progress)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = days; progressTintList = android.content.res.ColorStateList.valueOf(colors[stage]) }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 14))
        root.addView(text("OBJETIVOS DE HOY", 13f, Color.LTGRAY, true))
        val abs = CheckBox(this).apply { text = "Abdominales"; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(colors[stage]) }
        val push = CheckBox(this).apply { text = "Flexiones"; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(colors[stage]) }
        root.addView(abs); root.addView(push)
        root.addView(text("Adapta los ejercicios a tu capacidad y descansa cuando lo necesites.", 12f, Color.GRAY))
        root.addView(text("CONTADOR DE PASOS", 13f, Color.LTGRAY, true))
        stepText = text("Pasos: $steps", 22f, Color.WHITE, true); root.addView(stepText)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val minus = Button(this).apply { text = "− 1.000"; setOnClickListener { steps = (steps - 1000).coerceAtLeast(0); save(); refresh() } }
        val plus = Button(this).apply { text = "+ 1.000"; setOnClickListener { steps += 1000; save(); refresh() } }
        row.addView(minus, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); row.addView(plus, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); root.addView(row)
        val complete = Button(this).apply { text = "MARCAR DÍA COMO COMPLETADO"; setOnClickListener { if (!(stage == 3 && days == 100)) { days++; if (days >= 100 && stage < 3) { days = 0; stage++ }; save(); refresh(); stageText.text = "ETAPA ${stages[stage]}"; stageText.setTextColor(colors[stage]); Toast.makeText(this@MainActivity, "¡Progreso guardado!", Toast.LENGTH_SHORT).show() } } }
        root.addView(complete)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }
    private fun save() { prefs.edit().putInt("stage", stage).putInt("days", days).putInt("steps", steps).apply(); updateWidget() }
    private fun refresh() { progress.text = "$days% · $days de 100 días"; bar.progress = days; bar.progressTintList = android.content.res.ColorStateList.valueOf(colors[stage]); stepText.text = "Pasos: $steps"; updateWidget() }
    private fun updateWidget() { val mgr = AppWidgetManager.getInstance(this); val ids = mgr.getAppWidgetIds(ComponentName(this, AscendWidget::class.java)); for (id in ids) AscendWidget.update(this, mgr, id) }
}
