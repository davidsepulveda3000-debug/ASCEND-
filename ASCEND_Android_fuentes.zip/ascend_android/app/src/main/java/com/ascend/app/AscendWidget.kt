package com.ascend.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class AscendWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { for (id in ids) update(context, manager, id) }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val p = context.getSharedPreferences("ascend", Context.MODE_PRIVATE)
            val stage = p.getInt("stage", 0).coerceIn(0,3); val days = p.getInt("days", 0); val steps = p.getInt("steps", 0)
            val names = arrayOf("VERDE", "AZUL", "ROJO", "MORADO"); val colors = intArrayOf(0xFF22C55E.toInt(),0xFF3B82F6.toInt(),0xFFEF4444.toInt(),0xFFA855F7.toInt())
            val v = RemoteViews(context.packageName, R.layout.widget_ascend)
            v.setTextViewText(R.id.widget_title, "ASCEND · ETAPA ${names[stage]}"); v.setTextColor(R.id.widget_title, colors[stage])
            v.setTextViewText(R.id.widget_progress, "$days% · $days de 100 días"); v.setProgressBar(R.id.widget_bar, 100, days, false)
            v.setTextViewText(R.id.widget_steps, "Pasos: $steps"); manager.updateAppWidget(id, v)
        }
    }
}
