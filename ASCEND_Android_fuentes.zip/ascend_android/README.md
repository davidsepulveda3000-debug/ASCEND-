# ASCEND Android

Proyecto Android nativo de ejemplo para generar un APK con GitHub Actions. Incluye una pantalla principal y un widget de pantalla de inicio. El progreso y los pasos se guardan localmente.

## Compilar

Se compila en GitHub Actions con Android Gradle Plugin 8.7.3 y JDK 17.
